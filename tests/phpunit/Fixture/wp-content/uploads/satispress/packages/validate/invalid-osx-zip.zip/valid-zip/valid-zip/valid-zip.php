<?php
/**
 * Plugin Name: Basic Plugin
 * Plugin URI:  https://example.com/plugin/basic/
 * Description: A basic plugin description.
 * Version:     1.0.0
 * Author:      Basic, Inc.
 * Author URI:  https://example.com/
 * License:     GPL-2.0+
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: basic
 * Domain Path: /languages
 */
